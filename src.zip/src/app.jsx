import React from 'react'
import { CopyToClipboard } from 'react-copy-to-clipboard'
import { useState } from 'react'
const App = () => {
    const [text, settext] = useState("")
    console.log(text);
    const GetValue=(e)=>{
settext(e.target.value)
    }
const ClearText=()=>{
    settext("")
}
const Uppercase=()=>{
    const text2=text.toUpperCase()
    settext(text2)
}
const Lowercase=()=>{
    const text2=text.toLocaleLowerCase()
    settext(text2)
}
const RemoveSpace=()=>{
    const text3=text.replace(/\s+/g, ' ')
    settext(text3)
}
    return (
        <div className="container">
            <div class="form-floating mt-5">
  <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" value={text} onChange={GetValue}></textarea>
  <label for="floatingTextarea"></label>
</div>
            <button className="btn btn-primary m-2" onClick={ClearText}>Clear Text</button>
            <button className="btn btn-primary m-2" onClick={Uppercase}>Uppercase</button>
            <button className="btn btn-primary m-2" onClick={Lowercase}>Lowercase</button>
            <CopyToClipboard text={text}>
            <button className="btn btn-primary m-2">Copy</button>
            </CopyToClipboard>
            <button className="btn btn-primary m-2" onClick={RemoveSpace}>Remove extra spacing</button>
        </div>
    )
}

export default App
